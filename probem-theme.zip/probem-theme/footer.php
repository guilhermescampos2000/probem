<footer class="site-footer">
    <div class="container">
        <div class="footer-widgets">
            <?php dynamic_sidebar('footer-widget-area'); ?>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Instituto ProbEM. Todos os direitos reservados.</p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>